
public class Admin extends User {

	public Admin(int id_user,String nom,String username,String password,boolean smt) {
		
		
	}
//	public void createUser(String nom,String username,String password) {
//		User user=new User();
//		user.setNom(nom);
//		user.setUsername(username);
//		user.setPassword(password);
//		Controlleur.getListUser().add(user);
//	}
//	public void deleteUser(User e){
//		Controlleur.getListUser().remove(e);
//		}
//	public void modifyUser(User e,String nom,String username,String password) {
//		deleteUser(e);
//		createUser(nom , username , password);
//		}
	
}
