
public class Dossier extends Element {


	public Dossier(int id_element,String name) {}
	
	

public Dossier() {}


}
