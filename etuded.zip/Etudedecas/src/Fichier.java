
public class Fichier extends Element {
	private int taille;
	public int getTaille() {
		return taille;
	}
	public Fichier() {
		super();
		this.taille = taille;
	}
	public void setTaille(int taille) {
		this.taille = taille;
	}
}